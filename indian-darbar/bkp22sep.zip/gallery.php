<?php include_once('header.php');?>

            <div class="container-xxl py-5 bg-dark hero-header mb-5">
                <div class="container text-center my-5 pt-5 pb-4">
                    <h1 class="display-3 text-white mb-3 animated slideInDown">Gallery</h1>
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb justify-content-center text-uppercase">
                            <li class="breadcrumb-item"><a href="#">Home</a></li>
                            <li class="breadcrumb-item"><a href="#">Pages</a></li>
                            <li class="breadcrumb-item text-white active" aria-current="page">Menu</li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
        <!-- Navbar & Hero End -->


        <!-- Menu Start -->
        <div class="container-xxl py-5">
             <div class="container-row">
    <div class="grid-item">
      <a data-fancybox="gallery" href="https://images.unsplash.com/photo-1479064312651-24524fb55c0e?crop=entropy&cs=srgb&fm=jpg&ixid=MnwxNDU4OXwwfDF8cmFuZG9tfHx8fHx8fHx8MTYyOTU3MTQwNQ&ixlib=rb-1.2.1&q=85"><img src="https://images.unsplash.com/photo-1479064312651-24524fb55c0e?crop=entropy&cs=srgb&fm=jpg&ixid=MnwxNDU4OXwwfDF8cmFuZG9tfHx8fHx8fHx8MTYyOTU3MTQwNQ&ixlib=rb-1.2.1&q=85"></a>
    </div>
    <div class="grid-item">
      <a data-fancybox="gallery" href="https://images.unsplash.com/photo-1527698334848-f475f9d99449?crop=entropy&cs=srgb&fm=jpg&ixid=MnwxNDU4OXwwfDF8cmFuZG9tfHx8fHx8fHx8MTYyOTU3MTQwNQ&ixlib=rb-1.2.1&q=85"><img src="https://images.unsplash.com/photo-1527698334848-f475f9d99449?crop=entropy&cs=srgb&fm=jpg&ixid=MnwxNDU4OXwwfDF8cmFuZG9tfHx8fHx8fHx8MTYyOTU3MTQwNQ&ixlib=rb-1.2.1&q=85"></a>
    </div>
    <div class="grid-item">
      <a data-fancybox="gallery" href="https://images.unsplash.com/photo-1466781783364-36c955e42a7f?crop=entropy&cs=srgb&fm=jpg&ixid=MnwxNDU4OXwwfDF8cmFuZG9tfHx8fHx8fHx8MTYyOTU3MTQwNQ&ixlib=rb-1.2.1&q=85"><img src="https://images.unsplash.com/photo-1466781783364-36c955e42a7f?crop=entropy&cs=srgb&fm=jpg&ixid=MnwxNDU4OXwwfDF8cmFuZG9tfHx8fHx8fHx8MTYyOTU3MTQwNQ&ixlib=rb-1.2.1&q=85"></a>
    </div>
    <div class="grid-item">
      <a data-fancybox="gallery" href="https://images.unsplash.com/photo-1508968419-73cca394e8aa?crop=entropy&cs=srgb&fm=jpg&ixid=MnwxNDU4OXwwfDF8cmFuZG9tfHx8fHx8fHx8MTYyOTU3MTQwNQ&ixlib=rb-1.2.1&q=85"><img src="https://images.unsplash.com/photo-1508968419-73cca394e8aa?crop=entropy&cs=srgb&fm=jpg&ixid=MnwxNDU4OXwwfDF8cmFuZG9tfHx8fHx8fHx8MTYyOTU3MTQwNQ&ixlib=rb-1.2.1&q=85"></a>
    </div>
    <div class="grid-item">
      <a data-fancybox="gallery" href="https://images.unsplash.com/photo-1564951434112-64d74cc2a2d7?crop=entropy&cs=srgb&fm=jpg&ixid=MnwxNDU4OXwwfDF8cmFuZG9tfHx8fHx8fHx8MTYyOTU3MTQwNQ&ixlib=rb-1.2.1&q=85"><img src="https://images.unsplash.com/photo-1564951434112-64d74cc2a2d7?crop=entropy&cs=srgb&fm=jpg&ixid=MnwxNDU4OXwwfDF8cmFuZG9tfHx8fHx8fHx8MTYyOTU3MTQwNQ&ixlib=rb-1.2.1&q=85"></a>
    </div>
    <div class="grid-item">
      <a data-fancybox="gallery" href="https://images.unsplash.com/photo-1550859492-d5da9d8e45f3?crop=entropy&cs=srgb&fm=jpg&ixid=MnwxNDU4OXwwfDF8cmFuZG9tfHx8fHx8fHx8MTYyOTU3MTQwNQ&ixlib=rb-1.2.1&q=85"><img src="https://images.unsplash.com/photo-1550859492-d5da9d8e45f3?crop=entropy&cs=srgb&fm=jpg&ixid=MnwxNDU4OXwwfDF8cmFuZG9tfHx8fHx8fHx8MTYyOTU3MTQwNQ&ixlib=rb-1.2.1&q=85"></a>
    </div>
    <div class="grid-item">
      <a data-fancybox="gallery" href="https://images.unsplash.com/photo-1627626167513-e0bed2b4cff3?crop=entropy&cs=srgb&fm=jpg&ixid=MnwxNDU4OXwwfDF8cmFuZG9tfHx8fHx8fHx8MTYyOTU3MTU2NQ&ixlib=rb-1.2.1&q=85"><img src="https://images.unsplash.com/photo-1627626167513-e0bed2b4cff3?crop=entropy&cs=srgb&fm=jpg&ixid=MnwxNDU4OXwwfDF8cmFuZG9tfHx8fHx8fHx8MTYyOTU3MTU2NQ&ixlib=rb-1.2.1&q=85"></a>
    </div>
    <div class="grid-item">
      <a data-fancybox="gallery" href="https://images.unsplash.com/photo-1628230704059-be5735f707d1?crop=entropy&cs=srgb&fm=jpg&ixid=MnwxNDU4OXwwfDF8cmFuZG9tfHx8fHx8fHx8MTYyOTU3MTU2NQ&ixlib=rb-1.2.1&q=85"><img src="https://images.unsplash.com/photo-1628230704059-be5735f707d1?crop=entropy&cs=srgb&fm=jpg&ixid=MnwxNDU4OXwwfDF8cmFuZG9tfHx8fHx8fHx8MTYyOTU3MTU2NQ&ixlib=rb-1.2.1&q=85"></a>
    </div>
    <div class="grid-item">
      <a data-fancybox="gallery" href="https://images.unsplash.com/photo-1629019638491-c89d444bacaf?crop=entropy&cs=srgb&fm=jpg&ixid=MnwxNDU4OXwwfDF8cmFuZG9tfHx8fHx8fHx8MTYyOTU3MTU2NQ&ixlib=rb-1.2.1&q=85"><img src="https://images.unsplash.com/photo-1629019638491-c89d444bacaf?crop=entropy&cs=srgb&fm=jpg&ixid=MnwxNDU4OXwwfDF8cmFuZG9tfHx8fHx8fHx8MTYyOTU3MTU2NQ&ixlib=rb-1.2.1&q=85"></a>
    </div>
    <div class="grid-item">
      <a data-fancybox="gallery" href="https://images.unsplash.com/photo-1629463581326-72547415bcaf?crop=entropy&cs=srgb&fm=jpg&ixid=MnwxNDU4OXwwfDF8cmFuZG9tfHx8fHx8fHx8MTYyOTU3MTU2NQ&ixlib=rb-1.2.1&q=85"><img src="https://images.unsplash.com/photo-1629463581326-72547415bcaf?crop=entropy&cs=srgb&fm=jpg&ixid=MnwxNDU4OXwwfDF8cmFuZG9tfHx8fHx8fHx8MTYyOTU3MTU2NQ&ixlib=rb-1.2.1&q=85"></a>
    </div>
  </div>
        </div>
        <!-- Menu End -->
        

<?php include_once('footer.php');?>

</body>

</html>